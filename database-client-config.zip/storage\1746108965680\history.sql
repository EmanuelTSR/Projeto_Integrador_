/* 2025-05-01 11:17:38 [8 ms] */ 
CREATE DATABASE BancoPI;
/* 2025-05-01 11:21:30 [19 ms] */ 
CREATE TABLE PRODUTOS(
    codigo INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50),
    valor DOUBLE,
    imagem VARCHAR(50)
);
/* 2025-05-20 17:51:13 [1 ms] */ 
SELECT * FROM produtos LIMIT 100;
/* 2025-05-26 20:01:00 [28 ms] */ 
DELETE FROM `produtos` WHERE `codigo`=1;
/* 2025-06-20 11:06:09 [102 ms] */ 
CREATE TABLE historico_baixas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  produto_codigo INT,
  quantidade INT,
  motivo VARCHAR(255),
  data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (produto_codigo) REFERENCES produtos(codigo)
);
/* 2025-06-20 12:35:22 [143 ms] */ 
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(255) UNIQUE NOT NULL,
  senha VARCHAR(255) NOT NULL
);
